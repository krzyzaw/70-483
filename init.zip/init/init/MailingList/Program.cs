﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace MailingList
{
    class Program
    {
        static int totalPeopleCount;

        static void Main(string[] args)
        {
            //email_flood();
            run_test2();
        }


        static void run_test2()
        {
            while (consts.TRUE)
            {
                try
                {
                    Console.WriteLine("======================");
                    Console.WriteLine("*********MENU*********");
                    Console.WriteLine("1. Print all emails");
                    Console.WriteLine("2. Add email");
                    Console.WriteLine("3. Search email");
                    Console.WriteLine("4. Send message to all contacts");
                    Console.WriteLine("5. Synchronize");
                    Console.WriteLine("0. Exit");
                    Console.WriteLine("======================");

                    var x1 = Console.ReadLine();

                    switch (x1)
                    {
                        case "1":
                            Console.WriteLine("Mailing list");

                            foreach (var p in myList)
                                Console.WriteLine("{0} {1} {2}", p.Value[0], p.Value[1], p.Value[2]);

                            break;
                        case "2":
                            Console.WriteLine("Adding...");
                            #region fixed memory preparation (found somewhere on StackOverflow... works)
                            myList.Add(totalPeopleCount, new List<string>(4) { "", "", "", "" });
                            #endregion
                            Console.Write("First name: ");
                            myList[totalPeopleCount][0] = Console.ReadLine();
                            Console.Write("Last name: ");
                            myList[totalPeopleCount][1] = Console.ReadLine();
                            Console.Write("Mail: ");
                            myList[totalPeopleCount][2] = Console.ReadLine();
                            myList[totalPeopleCount][3] = Guid.NewGuid().ToString();
                            totalPeopleCount = totalPeopleCount + 1;// First we add the new person to list and then increase. Keep it like that!
                            var bad = myList.Values.Select(i => i[0].ToLower() + i[1].ToLower()).GroupBy(i => i).Where(g => g.Count() > 1).Select(y => y.Key).ToList();
                            if (bad.Count > 0) myList.Remove(--totalPeopleCount);

                            break;
                        case "3":
                            Console.Write("Search pattern: ");
                            string pattern = Console.ReadLine();
                            Console.WriteLine("Searching");

                            foreach (var p in myList.Where(p => p.Value.Any(i => i.Contains(pattern))))
                                Console.WriteLine("{0} {1} {2}", p.Value[0], p.Value[1], p.Value[2]);

                            break;
                        case "4":
                            Console.Write("Message to send: ");
                            string message = Console.ReadLine();
                            foreach (var p in myList)
                                SendEmail(p.Value[2], message);

                            break;
                        case "5":
                            Console.WriteLine("Synchronization in progress");
                            string _getUrl = "http://localhost:10200/api/Contacts/get";
                            string _postUrl = "http://localhost:10200/api/Contacts/post";

                            using (var client = new WebClient())
                            {
                                foreach (var contact in myList.Values)
                                {
                                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(new DataInterface() { FirstName = contact[0], LastName = contact[1], Email = contact[2], Id = Guid.Parse(contact[3]) });
                                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                                    var result = client.UploadString(_getUrl, "POST", json);
                                }
                                string contactsToAdd = client.DownloadString(_getUrl);

                                var contactsFromServer = Newtonsoft.Json.JsonConvert.DeserializeObject<List<DataInterface>>(contactsToAdd);
                                int newStuff = 0;

                                foreach (var c in contactsFromServer)
                                {
                                    bool exist = false;

                                    for (int i = 0; i < myList.Count; i++)
                                    {
                                        if (myList[i][3] == c.Id.ToString())
                                            exist = true;
                                    }

                                    if (!exist)
                                    {
                                        #region fixed memory preparation
                                        myList.Add(totalPeopleCount, new List<string>(10) { "", "", "", "", "", "", "", "", "", "" });
                                        #endregion
                                        //myList[0][0] = c.FirstName;
                                        //myList[0][1] = c.LastName;
                                        //myList[0][2] = c.Phone;
                                        //myList[0][3] = c.Id.ToString();
                                        myList[totalPeopleCount][0] = c.FirstName;
                                        myList[totalPeopleCount][1] = c.LastName;
                                        myList[totalPeopleCount][2] = c.Email;
                                        myList[totalPeopleCount][3] = c.Id.ToString();
                                        newStuff++;
                                    }
                                }

                                Console.WriteLine($"Send:{myList.Count} Received:{contactsFromServer.Count} New:{newStuff}");
                            }
                            break;
                        case "0":
                            Console.WriteLine("Exiting...");
                            Environment.Exit(0);
                            return;
                        default:
                            break;
                    }
                }
                catch (Exception exc)
                {
                    var c = Console.ForegroundColor;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("ERROR!");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("ERROR:" + exc.Message);
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("ERROR!");
                    Console.ForegroundColor = c;
                }
            }
        }

        private static void email_flood()
        {
            for (int i = 0; i < 50; i++)
                SendEmail("kzawist@intratic.eu", "test_" + i);
        }

        private static void SendEmail(string email, string message)
        {
            Console.WriteLine($"Sending email message: '{message}' to: {email}");
        }

        static Dictionary<int, List<string>> myList = new Dictionary<int, List<string>>();
    }

    struct consts
    {
        public static bool TRUE = true;
    }
}